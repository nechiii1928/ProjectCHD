package com.nelson.chdefforts.Admin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.nelson.chdefforts.R;

public class AdminRegistration extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_registration);
    }
}
